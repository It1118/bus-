// Zentraler Cloudflare Worker: bedient sowohl die API-Routen
// als auch die gebauten statischen Dateien (aus /dist), sodass
// "npx wrangler deploy" alles in einem Schritt ausliefert.

async function hashPassword(password, salt) {
  const enc = new TextEncoder();
  const data = enc.encode(password + salt);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

function generateSalt() {
  const arr = crypto.getRandomValues(new Uint8Array(16));
  return Array.from(arr).map(b => b.toString(16).padStart(2, '0')).join('');
}

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json' }
  });
}

async function authenticate(env, email, token) {
  return env.DB.prepare('SELECT * FROM users WHERE email = ? AND session_token = ?')
    .bind(email, token).first();
}

async function handleRegister(request, env) {
  const { email, password } = await request.json();
  if (!email || !password || password.length < 6) {
    return json({ error: 'Ungültige Eingabe. Passwort muss mind. 6 Zeichen haben.' }, 400);
  }
  const existing = await env.DB.prepare('SELECT id FROM users WHERE email = ?').bind(email).first();
  if (existing) {
    return json({ error: 'Diese Email ist bereits registriert.' }, 409);
  }
  const salt = generateSalt();
  const passwordHash = await hashPassword(password, salt);
  const token = crypto.randomUUID();
  await env.DB.prepare(
    'INSERT INTO users (email, password_hash, salt, session_token, created_at) VALUES (?, ?, ?, ?, ?)'
  ).bind(email, passwordHash, salt, token, new Date().toISOString()).run();
  return json({ email, token });
}

async function handleLogin(request, env) {
  const { email, password } = await request.json();
  if (!email || !password) {
    return json({ error: 'Email und Passwort erforderlich.' }, 400);
  }
  const user = await env.DB.prepare('SELECT * FROM users WHERE email = ?').bind(email).first();
  if (!user) {
    return json({ error: 'Email oder Passwort falsch.' }, 401);
  }
  const hash = await hashPassword(password, user.salt);
  if (hash !== user.password_hash) {
    return json({ error: 'Email oder Passwort falsch.' }, 401);
  }
  const token = crypto.randomUUID();
  await env.DB.prepare('UPDATE users SET session_token = ? WHERE email = ?').bind(token, email).run();
  return json({ email: user.email, token });
}

async function handleDeleteAccount(request, env) {
  const { email, token } = await request.json();
  const user = await authenticate(env, email, token);
  if (!user) {
    return json({ error: 'Nicht autorisiert.' }, 401);
  }
  await env.DB.prepare('DELETE FROM schedules WHERE user_email = ?').bind(email).run();
  await env.DB.prepare('DELETE FROM users WHERE email = ?').bind(email).run();
  return json({ success: true });
}

async function handleSchedulesGet(request, env) {
  const url = new URL(request.url);
  const email = url.searchParams.get('email');
  const token = url.searchParams.get('token');
  const user = await authenticate(env, email, token);
  if (!user) {
    return json({ error: 'Nicht autorisiert.' }, 401);
  }
  const { results } = await env.DB.prepare(
    'SELECT * FROM schedules WHERE user_email = ? ORDER BY departure ASC'
  ).bind(email).all();
  return json({ schedules: results });
}

async function handleSchedulesPost(request, env) {
  const { email, token, line, destination, departure, delay } = await request.json();
  const user = await authenticate(env, email, token);
  if (!user) {
    return json({ error: 'Nicht autorisiert.' }, 401);
  }
  const id = crypto.randomUUID();
  await env.DB.prepare(
    'INSERT INTO schedules (id, user_email, line, destination, departure, delay, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)'
  ).bind(id, email, line, destination, departure, delay || 0, new Date().toISOString()).run();
  return json({ id, line, destination, departure, delay: delay || 0 });
}

async function handleSchedulesDelete(request, env) {
  const { email, token, id } = await request.json();
  const user = await authenticate(env, email, token);
  if (!user) {
    return json({ error: 'Nicht autorisiert.' }, 401);
  }
  await env.DB.prepare('DELETE FROM schedules WHERE id = ? AND user_email = ?').bind(id, email).run();
  return json({ success: true });
}

async function handleShareGet(id, env) {
  const schedule = await env.DB.prepare('SELECT * FROM schedules WHERE id = ?').bind(id).first();
  if (!schedule) {
    return json({ error: 'Fahrplan nicht gefunden.' }, 404);
  }
  return json({ schedule });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const path = url.pathname;
    const method = request.method;

    try {
      if (path === '/api/register' && method === 'POST') {
        return await handleRegister(request, env);
      }
      if (path === '/api/login' && method === 'POST') {
        return await handleLogin(request, env);
      }
      if (path === '/api/delete-account' && method === 'POST') {
        return await handleDeleteAccount(request, env);
      }
      if (path === '/api/schedules' && method === 'GET') {
        return await handleSchedulesGet(request, env);
      }
      if (path === '/api/schedules' && method === 'POST') {
        return await handleSchedulesPost(request, env);
      }
      if (path === '/api/schedules' && method === 'DELETE') {
        return await handleSchedulesDelete(request, env);
      }
      if (path.startsWith('/api/share/') && method === 'GET') {
        const id = path.split('/api/share/')[1];
        return await handleShareGet(id, env);
      }
    } catch (err) {
      return json({ error: 'Serverfehler: ' + err.message }, 500);
    }

    // Alles andere: statische Dateien aus /dist ausliefern
    return env.ASSETS.fetch(request);
  }
};

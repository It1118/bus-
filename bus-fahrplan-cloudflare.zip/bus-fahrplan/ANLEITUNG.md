# Bus Fahrplan Manager – Deployment auf Cloudflare

Dieses Projekt ist jetzt vollständig Cloudflare-tauglich und nutzt den modernen
**Cloudflare Workers Static-Assets-Modus** (ein Worker liefert sowohl die API
als auch die gebauten Frontend-Dateien aus – funktioniert mit `wrangler deploy`,
so wie es Cloudflare Git-Integrationen standardmäßig ausführen):

- **Frontend:** React + Vite + Tailwind (statisch, gebaut nach `dist/`)
- **Backend:** ein zentrales Worker-Script (`src/worker.js`), das API-Routen und
  statische Dateien bedient
- **Datenbank:** Cloudflare D1 (SQL-Datenbank), Passwörter werden gehasht (SHA-256 + Salt) gespeichert

## Wichtig: Build-Command im Cloudflare-Dashboard setzen

Wenn du das Projekt per Git-Repository verbindest, muss Cloudflare vor dem Deploy
erst `npm install` und `npm run build` ausführen, damit der Ordner `dist/`
überhaupt entsteht. Trage im Dashboard unter
**Settings → Build → Build command** ein:

```
npm install && npm run build
```

**Deploy command** bleibt:

```
npx wrangler deploy
```

Ohne diesen Build-Schritt schlägt der Deploy fehl mit der Meldung
„Could not detect a directory containing static files" – genau das war das
ursprüngliche Problem.

## Voraussetzungen

- Ein kostenloser Cloudflare-Account
- Node.js installiert
- Wrangler CLI: `npm install -g wrangler`

## Schritt 1: Bei Cloudflare anmelden

```bash
wrangler login
```

## Schritt 2: D1-Datenbank erstellen

```bash
wrangler d1 create bus-fahrplan-db
```

Das gibt dir eine `database_id` aus. Trage sie in `wrangler.toml` bei
`database_id = "..."` ein (ersetze `REPLACE_WITH_YOUR_DATABASE_ID`).

## Schritt 3: Datenbank-Schema anlegen

```bash
wrangler d1 execute bus-fahrplan-db --remote --file=./schema.sql
```

Das erstellt die Tabellen `users` und `schedules` in deiner Cloudflare-Datenbank.

## Schritt 4: Projekt bauen

```bash
npm install
npm run build
```

Das erzeugt den Ordner `dist/` mit der fertigen Webseite.

## Schritt 5: Deployment

### Option A – Direkt per Wrangler CLI

```bash
wrangler pages deploy dist --project-name=bus-fahrplan
```

Wrangler fragt beim ersten Mal, ob ein neues Pages-Projekt angelegt werden soll — mit Ja bestätigen.

**Wichtig:** Nach dem ersten Deploy musst du die D1-Datenbank noch mit dem Pages-Projekt verknüpfen,
das geht am einfachsten im Cloudflare Dashboard:

1. Gehe zu **Workers & Pages** → dein Projekt `bus-fahrplan`
2. **Settings** → **Functions** → **D1 database bindings**
3. Binding-Name: `DB`, Datenbank: `bus-fahrplan-db` auswählen → Speichern
4. Danach einmal neu deployen (`wrangler pages deploy dist`), damit die Bindung aktiv wird

### Option B – Über GitHub (empfohlen für automatische Updates)

1. Projekt in ein GitHub-Repository pushen
2. Im Cloudflare Dashboard: **Workers & Pages** → **Create** → **Pages** → **Connect to Git**
3. Repository auswählen
4. Build-Einstellungen:
   - **Build command:** `npm run build`
   - **Build output directory:** `dist`
5. Nach dem ersten Deploy: D1-Datenbank binden wie oben unter Option A beschrieben
6. Jeder `git push` deployt danach automatisch neu

## Lokal testen (mit echter D1-Anbindung)

```bash
npm run build
wrangler pages dev dist --d1=DB=bus-fahrplan-db
```

Öffnet die Seite lokal unter `http://localhost:8788` — inklusive funktionierendem Backend.

## Was wurde gegenüber der ersten Version verbessert?

- **Keine Passwörter mehr im Klartext:** Passwörter werden mit SHA-256 + individuellem Salt gehasht,
  bevor sie in der Datenbank landen.
- **Echte Server-Datenbank statt localStorage:** Nutzerdaten und Fahrpläne sind jetzt geräteübergreifend
  verfügbar und gehen nicht verloren, wenn der Browser-Speicher geleert wird.
- **Session-Token:** Anmeldung erzeugt ein Token, das serverseitig geprüft wird – kein Zugriff auf fremde Daten möglich.
- **Öffentliche Fahrplan-Links funktionieren jetzt wirklich:** `/?share=<id>` ruft die Daten live aus der
  Datenbank ab, keine Kodierung in der URL mehr nötig – auch für andere Personen ohne Login nutzbar.

## Projektstruktur

```
bus-fahrplan/
├── src/                  React-Frontend
├── functions/api/        Cloudflare Pages Functions (Backend)
│   ├── register.js
│   ├── login.js
│   ├── delete-account.js
│   ├── schedules.js
│   └── share/[id].js
├── schema.sql            Datenbank-Struktur
├── wrangler.toml          Cloudflare-Konfiguration
└── package.json
```
